// CubeWorld
// SPDX-License-Identifier: LGPL-2.1-or-later
// Copyright (C) 2013 zodiac <celeron55@gmail.com>

#pragma once

#include <vector>
#include <string>
#include <set>
#include <unordered_set>
#include "metadata.h"

class ModStorageDatabase;
struct ModSpec;

#define MODNAME_ALLOWED_CHARS "abcdefghijklmnopqrstuvwxyz0123456789_"

struct ModSpecCompare {
	bool operator()(const ModSpec &a, const ModSpec &b) const;
};
using ModSpecList = std::set<ModSpec, ModSpecCompare>;

struct ModSpec
{
	bool is_name_explicit = false; //< 'Specified in a .conf file?'
	std::string name;
	std::string author;
	std::string path; // absolute path on disk
	std::string desc;
	int release = 0;

	// if normal mod:
	std::unordered_set<std::string> depends;
	std::unordered_set<std::string> optdepends;
	std::unordered_set<std::string> unsatisfied_depends;

	int modpack_depth = 0; //< Modpack depth, 0 = no parent modpack
	bool is_modpack = false;

	/**
	 * A constructed canonical path to represent this mod's location.
	 * This intended to be used as an identifier for a modpath that tolerates file movement,
	 * and cannot be used to read the mod files.
	 *
	 * Note that `mymod` is the directory name, not the mod name specified in mod.conf.
	 *
	 * Ex:
	 *
	 * - mods/mymod
	 * - mods/mymod (1)
	 *     (^ this would have name=mymod in mod.conf)
	 * - mods/modpack1/mymod
	 * - games/mygame/mods/mymod
	 * - worldmods/mymod
	 */
	std::string virtual_path;

	// For logging purposes
	std::vector<const char *> deprecation_msgs;

	// if modpack:
	ModSpecList modpack_content;

	ModSpec()
	{
	}

	ModSpec(const std::string &name, const std::string &path, int modpack_depth, const std::string &virtual_path) :
			name(name), path(path), modpack_depth(modpack_depth), virtual_path(virtual_path)
	{
	}

	void checkAndLog() const;
};

/**
 * Retrieves depends, optdepends, is_modpack and modpack_content
 *
 * @returns false if not a mod
 */
[[nodiscard]] bool parseModContents(ModSpec &mod);

/**
 * Gets a list of all mods and modpacks in path
 *
 * @param Path to search, should be absolute
 * @param modpack_depth If > 0: Is this searching within a modpack
 * @param virtual_path Virtual path for this directory, see comment in ModSpec
 * @returns list of mods, sorted by name
 */
ModSpecList getModsInPath(const std::string &path,
		const std::string &virtual_path, int modpack_depth = 0);

// replaces modpack Modspecs with their content
std::vector<ModSpec> flattenMods(const ModSpecList &mods,
		bool discard_modpacks);


class ModStorage : public IMetadata
{
public:
	ModStorage() = delete;
	ModStorage(const std::string &mod_name, ModStorageDatabase *database);
	~ModStorage() = default;

	const std::string &getModName() const { return m_mod_name; }

	void clear() override;

	bool contains(const std::string &name) const override;

	bool setString(const std::string &name, std::string_view var) override;

	const StringMap &getStrings(StringMap *place) const override;

	const std::vector<std::string> &getKeys(std::vector<std::string> *place) const override;

protected:
	const std::string *getStringRaw(const std::string &name,
			std::string *place) const override;

private:
	std::string m_mod_name;
	ModStorageDatabase *m_database;
};
